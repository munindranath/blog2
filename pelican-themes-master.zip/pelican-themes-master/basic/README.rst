Basic
#####

This theme has been made for the documentation of the template inheritance feature of Pelican.

He is usable, but only works with the last version of Pelican from the GIT repository...

It supports Google Analytics and has a Jappix widget.

Screenshot
----------

.. image:: screenshot.png
   :alt: Screenshot of the basic theme

