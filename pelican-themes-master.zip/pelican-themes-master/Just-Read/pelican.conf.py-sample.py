AUTHOR = 'Name Lastname'
SITENAME = "The name of your website"
SITEURL = 'http://example.com'
TIMEZONE = ""

DISQUS_SITENAME = ''

DEFAULT_DATE_FORMAT = '%d/%m/%Y'
REVERSE_ARCHIVE_ORDER = True
TAG_CLOUD_STEPS = 8

PATH = ''
THEME = ''
OUTPUT_PATH = ''

MARKUP = 'md'
MD_EXTENSIONS = 'extra'

FEED_RSS = 'feeds/all.rss.xml'
TAG_FEED_RSS = 'feeds/%s.rss.xml'

GOOGLE_ANALYTICS = 'UA-XXXXX-X'
HTML_LANG = 'es'
TWITTER_USERNAME = ''

SOCIAL = (('GitHub',  'http://github.com/yourusername'),
          ('Twitter', 'http://twitter.com/yourusername'),)